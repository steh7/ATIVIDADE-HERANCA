/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ATIVIDADE3;

/**
 *
 * @author Admin
 */
public class Rica extends Pessoa {
    @Override
    public void status() {
        System.out.println("Pessoa rica.");
    }
}