/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ATIVIDADE1;

import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class MainFuncionario {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Cria Assistente Administrativo e Técnico
        AssistenteAdministrativo assistente = new AssistenteAdministrativo(1, "Ana");
        Tecnico tecnico = new Tecnico(2, "João");

        // Imprime dados
        System.out.println("Assistente Administrativo:");
        System.out.println("Matrícula: " + assistente.getMatricula());
        System.out.println("Nome: " + assistente.getNome());

        System.out.println("\nTécnico:");
        System.out.println("Matrícula: " + tecnico.getMatricula());
        System.out.println("Nome: " + tecnico.getNome());
    }
}