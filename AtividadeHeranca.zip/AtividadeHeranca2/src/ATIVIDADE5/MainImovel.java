/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ATIVIDADE5;

import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class MainImovel {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite 1 para imóvel novo e 2 para imóvel velho:");
        int escolha = scanner.nextInt();
        double valor = 0.0;

        if (escolha == 1) {
            valor = 300000.0; // Valor para imóvel novo
        } else if (escolha == 2) {
            valor = 150000.0; // Valor para imóvel velho
        } else {
            System.out.println("Escolha inválida.");
            return;
        }

        Imovel imovel = new Imovel(valor);
        System.out.println("Valor final do imóvel: R$ " + imovel.getValor());
    }
}