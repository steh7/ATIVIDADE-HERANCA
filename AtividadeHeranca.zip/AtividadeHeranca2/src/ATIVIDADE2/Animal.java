/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ATIVIDADE2;

/**
 *
 * @author Admin
 */
public abstract class Animal {
    public abstract void emitirSom();
    public void caminhar() {
        System.out.println("O animal está caminhando.");
    }
}