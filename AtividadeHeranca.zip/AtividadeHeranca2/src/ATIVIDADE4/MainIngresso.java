/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ATIVIDADE4;

import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class MainIngresso {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite 1 para ingresso normal e 2 para VIP:");
        int escolha = scanner.nextInt();
        Ingresso ingresso;
        double valor = 0.00;

        if (escolha == 1) {
            ingresso = new Ingresso("Normal", 50.00);
        } else if (escolha == 2) {
            System.out.println("Digite 1 para camarote superior e 2 para camarote inferior:");
            int tipoVIP = scanner.nextInt();
            if (tipoVIP == 1) {
                ingresso = new Ingresso("VIP - Camarote Superior", 150.00);
            } else {
                ingresso = new Ingresso("VIP - Camarote Inferior", 100.00);
            }
        } else {
            System.out.println("Escolha inválida.");
            return;
        }

        System.out.println("Tipo de ingresso: " + ingresso.getTipo());
        System.out.println("Valor: R$ " + ingresso.getValor());
    }
}